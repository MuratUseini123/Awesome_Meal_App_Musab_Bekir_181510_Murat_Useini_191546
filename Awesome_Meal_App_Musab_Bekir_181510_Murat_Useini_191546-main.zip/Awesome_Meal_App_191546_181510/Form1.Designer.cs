﻿
namespace Awesome_Meal_App_191546_181510
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.pnlEmployee = new System.Windows.Forms.Panel();
            this.btnHomePageProdEdit = new System.Windows.Forms.Button();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.btnProdLstEdit = new System.Windows.Forms.Button();
            this.verticalLine = new System.Windows.Forms.FlowLayoutPanel();
            this.button4 = new System.Windows.Forms.Button();
            this.staffmemberLogOutlbl = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.btnProdPanelActivate = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.brandPic = new System.Windows.Forms.PictureBox();
            this.btnTwiter = new System.Windows.Forms.Button();
            this.btnFacebook = new System.Windows.Forms.Button();
            this.btnInstagram = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.productList = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlAbout = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.loggedStaffMemberInfoPnl = new System.Windows.Forms.Panel();
            this.txtStMemberMessage = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pnlCustomerMessage = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.homePageProduct = new Awesome_Meal_App_191546_181510.HomePageProduct();
            this.panel1.SuspendLayout();
            this.pnlEmployee.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.brandPic)).BeginInit();
            this.pnlAbout.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.loggedStaffMemberInfoPnl.SuspendLayout();
            this.pnlCustomerMessage.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.pnlEmployee);
            this.panel1.Controls.Add(this.verticalLine);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.staffmemberLogOutlbl);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.btnProdPanelActivate);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(860, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(220, 768);
            this.panel1.TabIndex = 0;
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(0, 194);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(209, 52);
            this.button2.TabIndex = 8;
            this.button2.Text = "     Procced to payment";
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pnlEmployee
            // 
            this.pnlEmployee.Controls.Add(this.btnHomePageProdEdit);
            this.pnlEmployee.Controls.Add(this.btnLogOut);
            this.pnlEmployee.Controls.Add(this.btnProdLstEdit);
            this.pnlEmployee.Location = new System.Drawing.Point(0, 577);
            this.pnlEmployee.Name = "pnlEmployee";
            this.pnlEmployee.Size = new System.Drawing.Size(209, 156);
            this.pnlEmployee.TabIndex = 7;
            this.pnlEmployee.Visible = false;
            // 
            // btnHomePageProdEdit
            // 
            this.btnHomePageProdEdit.Enabled = false;
            this.btnHomePageProdEdit.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnHomePageProdEdit.FlatAppearance.BorderSize = 0;
            this.btnHomePageProdEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHomePageProdEdit.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnHomePageProdEdit.ForeColor = System.Drawing.Color.White;
            this.btnHomePageProdEdit.Location = new System.Drawing.Point(0, 3);
            this.btnHomePageProdEdit.Name = "btnHomePageProdEdit";
            this.btnHomePageProdEdit.Size = new System.Drawing.Size(206, 52);
            this.btnHomePageProdEdit.TabIndex = 9;
            this.btnHomePageProdEdit.Text = "   Edit Home Page Product";
            this.btnHomePageProdEdit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHomePageProdEdit.UseVisualStyleBackColor = true;
            this.btnHomePageProdEdit.Visible = false;
            this.btnHomePageProdEdit.Click += new System.EventHandler(this.btnHomePageProdEdit_Click);
            // 
            // btnLogOut
            // 
            this.btnLogOut.Enabled = false;
            this.btnLogOut.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnLogOut.FlatAppearance.BorderSize = 0;
            this.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogOut.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnLogOut.ForeColor = System.Drawing.Color.White;
            this.btnLogOut.Image = ((System.Drawing.Image)(resources.GetObject("btnLogOut.Image")));
            this.btnLogOut.Location = new System.Drawing.Point(-1, 104);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(209, 52);
            this.btnLogOut.TabIndex = 8;
            this.btnLogOut.Text = "   Log-out";
            this.btnLogOut.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLogOut.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnLogOut.UseVisualStyleBackColor = true;
            this.btnLogOut.Visible = false;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // btnProdLstEdit
            // 
            this.btnProdLstEdit.Enabled = false;
            this.btnProdLstEdit.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnProdLstEdit.FlatAppearance.BorderSize = 0;
            this.btnProdLstEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProdLstEdit.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnProdLstEdit.ForeColor = System.Drawing.Color.White;
            this.btnProdLstEdit.Location = new System.Drawing.Point(0, 61);
            this.btnProdLstEdit.Name = "btnProdLstEdit";
            this.btnProdLstEdit.Size = new System.Drawing.Size(206, 52);
            this.btnProdLstEdit.TabIndex = 6;
            this.btnProdLstEdit.Text = "   Edit Product List";
            this.btnProdLstEdit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProdLstEdit.UseVisualStyleBackColor = true;
            this.btnProdLstEdit.Visible = false;
            this.btnProdLstEdit.Click += new System.EventHandler(this.btnProdLstEdit_Click);
            // 
            // verticalLine
            // 
            this.verticalLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(41)))), ((int)(((byte)(28)))));
            this.verticalLine.Location = new System.Drawing.Point(210, 84);
            this.verticalLine.Name = "verticalLine";
            this.verticalLine.Size = new System.Drawing.Size(10, 52);
            this.verticalLine.TabIndex = 2;
            // 
            // button4
            // 
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.Location = new System.Drawing.Point(3, 292);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(209, 52);
            this.button4.TabIndex = 5;
            this.button4.Text = " About";
            this.button4.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // staffmemberLogOutlbl
            // 
            this.staffmemberLogOutlbl.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.staffmemberLogOutlbl.ForeColor = System.Drawing.Color.White;
            this.staffmemberLogOutlbl.Location = new System.Drawing.Point(3, 736);
            this.staffmemberLogOutlbl.Name = "staffmemberLogOutlbl";
            this.staffmemberLogOutlbl.Size = new System.Drawing.Size(206, 32);
            this.staffmemberLogOutlbl.TabIndex = 0;
            this.staffmemberLogOutlbl.Text = "    EmployeeName";
            this.staffmemberLogOutlbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button3
            // 
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.Location = new System.Drawing.Point(-1, 242);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(209, 52);
            this.button3.TabIndex = 4;
            this.button3.Text = "        Employee Login";
            this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnProdPanelActivate
            // 
            this.btnProdPanelActivate.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnProdPanelActivate.FlatAppearance.BorderSize = 0;
            this.btnProdPanelActivate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProdPanelActivate.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnProdPanelActivate.ForeColor = System.Drawing.Color.White;
            this.btnProdPanelActivate.Image = ((System.Drawing.Image)(resources.GetObject("btnProdPanelActivate.Image")));
            this.btnProdPanelActivate.Location = new System.Drawing.Point(0, 136);
            this.btnProdPanelActivate.Name = "btnProdPanelActivate";
            this.btnProdPanelActivate.Size = new System.Drawing.Size(209, 52);
            this.btnProdPanelActivate.TabIndex = 3;
            this.btnProdPanelActivate.Text = "   Products";
            this.btnProdPanelActivate.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnProdPanelActivate.UseVisualStyleBackColor = true;
            this.btnProdPanelActivate.Click += new System.EventHandler(this.btnProdPanelActivate_Click);
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(0, 84);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(209, 52);
            this.button1.TabIndex = 2;
            this.button1.Text = "   Home    ";
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(41)))), ((int)(((byte)(28)))));
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(860, 27);
            this.panel2.TabIndex = 1;
            // 
            // brandPic
            // 
            this.brandPic.Image = ((System.Drawing.Image)(resources.GetObject("brandPic.Image")));
            this.brandPic.Location = new System.Drawing.Point(660, 12);
            this.brandPic.Name = "brandPic";
            this.brandPic.Size = new System.Drawing.Size(184, 157);
            this.brandPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.brandPic.TabIndex = 0;
            this.brandPic.TabStop = false;
            // 
            // btnTwiter
            // 
            this.btnTwiter.FlatAppearance.BorderSize = 0;
            this.btnTwiter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTwiter.Image = ((System.Drawing.Image)(resources.GetObject("btnTwiter.Image")));
            this.btnTwiter.Location = new System.Drawing.Point(530, 33);
            this.btnTwiter.Name = "btnTwiter";
            this.btnTwiter.Size = new System.Drawing.Size(59, 64);
            this.btnTwiter.TabIndex = 3;
            this.btnTwiter.UseVisualStyleBackColor = true;
            this.btnTwiter.Click += new System.EventHandler(this.btnTwiter_Click);
            // 
            // btnFacebook
            // 
            this.btnFacebook.FlatAppearance.BorderSize = 0;
            this.btnFacebook.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFacebook.Image = ((System.Drawing.Image)(resources.GetObject("btnFacebook.Image")));
            this.btnFacebook.Location = new System.Drawing.Point(595, 33);
            this.btnFacebook.Name = "btnFacebook";
            this.btnFacebook.Size = new System.Drawing.Size(59, 64);
            this.btnFacebook.TabIndex = 4;
            this.btnFacebook.UseVisualStyleBackColor = true;
            this.btnFacebook.Click += new System.EventHandler(this.btnFacebook_Click);
            // 
            // btnInstagram
            // 
            this.btnInstagram.FlatAppearance.BorderSize = 0;
            this.btnInstagram.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInstagram.Image = ((System.Drawing.Image)(resources.GetObject("btnInstagram.Image")));
            this.btnInstagram.Location = new System.Drawing.Point(465, 33);
            this.btnInstagram.Name = "btnInstagram";
            this.btnInstagram.Size = new System.Drawing.Size(59, 64);
            this.btnInstagram.TabIndex = 5;
            this.btnInstagram.UseVisualStyleBackColor = true;
            this.btnInstagram.Click += new System.EventHandler(this.btnInstagram_Click);
            // 
            // button5
            // 
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.Location = new System.Drawing.Point(12, 33);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(59, 64);
            this.button5.TabIndex = 6;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // productList
            // 
            this.productList.AutoScroll = true;
            this.productList.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.productList.Location = new System.Drawing.Point(4, 194);
            this.productList.Name = "productList";
            this.productList.Size = new System.Drawing.Size(772, 572);
            this.productList.TabIndex = 8;
            this.productList.WrapContents = false;
            // 
            // pnlAbout
            // 
            this.pnlAbout.AutoScroll = true;
            this.pnlAbout.Controls.Add(this.panel6);
            this.pnlAbout.Controls.Add(this.panel5);
            this.pnlAbout.Controls.Add(this.label3);
            this.pnlAbout.Controls.Add(this.label2);
            this.pnlAbout.Controls.Add(this.pictureBox1);
            this.pnlAbout.Controls.Add(this.label1);
            this.pnlAbout.Location = new System.Drawing.Point(6, 185);
            this.pnlAbout.Name = "pnlAbout";
            this.pnlAbout.Size = new System.Drawing.Size(794, 583);
            this.pnlAbout.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.label6);
            this.panel6.Controls.Add(this.label7);
            this.panel6.Controls.Add(this.pictureBox3);
            this.panel6.Location = new System.Drawing.Point(108, 1738);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(543, 720);
            this.panel6.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(0, 344);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(543, 358);
            this.label6.TabIndex = 2;
            this.label6.Text = resources.GetString("label6.Text");
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(0, 299);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(543, 52);
            this.label7.TabIndex = 1;
            this.label7.Text = "Staff Members";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(0, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(543, 296);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.label5);
            this.panel5.Controls.Add(this.label4);
            this.panel5.Controls.Add(this.pictureBox2);
            this.panel5.Location = new System.Drawing.Point(108, 950);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(543, 765);
            this.panel5.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(0, 355);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(540, 398);
            this.label5.TabIndex = 6;
            this.label5.Text = resources.GetString("label5.Text");
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(0, 303);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(543, 52);
            this.label4.TabIndex = 1;
            this.label4.Text = "Our History";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(543, 296);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(103, 504);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(572, 390);
            this.label3.TabIndex = 5;
            this.label3.Text = resources.GetString("label3.Text");
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(103, 451);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(572, 49);
            this.label2.TabIndex = 4;
            this.label2.Text = "Our story starts with you\r\n";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(233, 140);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(300, 285);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 24.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(313, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 45);
            this.label1.TabIndex = 1;
            this.label1.Text = "About Us";
            // 
            // loggedStaffMemberInfoPnl
            // 
            this.loggedStaffMemberInfoPnl.Controls.Add(this.txtStMemberMessage);
            this.loggedStaffMemberInfoPnl.Controls.Add(this.label9);
            this.loggedStaffMemberInfoPnl.Controls.Add(this.label8);
            this.loggedStaffMemberInfoPnl.Enabled = false;
            this.loggedStaffMemberInfoPnl.Location = new System.Drawing.Point(77, 36);
            this.loggedStaffMemberInfoPnl.Name = "loggedStaffMemberInfoPnl";
            this.loggedStaffMemberInfoPnl.Size = new System.Drawing.Size(392, 119);
            this.loggedStaffMemberInfoPnl.TabIndex = 9;
            this.loggedStaffMemberInfoPnl.Visible = false;
            // 
            // txtStMemberMessage
            // 
            this.txtStMemberMessage.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStMemberMessage.Location = new System.Drawing.Point(15, 48);
            this.txtStMemberMessage.Name = "txtStMemberMessage";
            this.txtStMemberMessage.Size = new System.Drawing.Size(361, 31);
            this.txtStMemberMessage.TabIndex = 2;
            this.txtStMemberMessage.Text = "label11";
            this.txtStMemberMessage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(17, 79);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(105, 21);
            this.label9.TabIndex = 1;
            this.label9.Text = "Staff member";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(15, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(114, 32);
            this.label8.TabIndex = 0;
            this.label8.Text = "Welcome";
            // 
            // pnlCustomerMessage
            // 
            this.pnlCustomerMessage.Controls.Add(this.label10);
            this.pnlCustomerMessage.Controls.Add(this.label12);
            this.pnlCustomerMessage.Enabled = false;
            this.pnlCustomerMessage.Location = new System.Drawing.Point(78, 36);
            this.pnlCustomerMessage.Name = "pnlCustomerMessage";
            this.pnlCustomerMessage.Size = new System.Drawing.Size(392, 119);
            this.pnlCustomerMessage.TabIndex = 10;
            this.pnlCustomerMessage.Visible = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(15, 47);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(175, 32);
            this.label10.TabIndex = 2;
            this.label10.Text = "Dear Customer";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(15, 15);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(114, 32);
            this.label12.TabIndex = 0;
            this.label12.Text = "Welcome";
            // 
            // homePageProduct
            // 
            this.homePageProduct.Category = "Fast Food";
            this.homePageProduct.Home_Product_Name = "Hamburger";
            this.homePageProduct.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(41)))), ((int)(((byte)(28)))));
            this.homePageProduct.Location = new System.Drawing.Point(0, 175);
            this.homePageProduct.Name = "homePageProduct";
            this.homePageProduct.ProductImage = ((System.Drawing.Image)(resources.GetObject("homePageProduct.ProductImage")));
            this.homePageProduct.ProductPrice = 35.5F;
            this.homePageProduct.Size = new System.Drawing.Size(815, 593);
            this.homePageProduct.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1080, 768);
            this.Controls.Add(this.pnlAbout);
            this.Controls.Add(this.pnlCustomerMessage);
            this.Controls.Add(this.productList);
            this.Controls.Add(this.loggedStaffMemberInfoPnl);
            this.Controls.Add(this.homePageProduct);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.btnInstagram);
            this.Controls.Add(this.btnFacebook);
            this.Controls.Add(this.btnTwiter);
            this.Controls.Add(this.brandPic);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Awesome Meal App";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.pnlEmployee.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.brandPic)).EndInit();
            this.pnlAbout.ResumeLayout(false);
            this.pnlAbout.PerformLayout();
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.loggedStaffMemberInfoPnl.ResumeLayout(false);
            this.loggedStaffMemberInfoPnl.PerformLayout();
            this.pnlCustomerMessage.ResumeLayout(false);
            this.pnlCustomerMessage.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox brandPic;
        private System.Windows.Forms.FlowLayoutPanel verticalLine;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btnProdPanelActivate;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnTwiter;
        private System.Windows.Forms.Button btnFacebook;
        private System.Windows.Forms.Button btnInstagram;
        private System.Windows.Forms.Button button5;
        private HomePageProduct homePageProduct;
        private System.Windows.Forms.FlowLayoutPanel productList;
        private System.Windows.Forms.Panel pnlAbout;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnProdLstEdit;
        private System.Windows.Forms.Panel loggedStaffMemberInfoPnl;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel pnlEmployee;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Label staffmemberLogOutlbl;
        private System.Windows.Forms.Panel pnlCustomerMessage;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnHomePageProdEdit;
        private System.Windows.Forms.Label txtStMemberMessage;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button2;
    }
}

