﻿
namespace Awesome_Meal_App_191546_181510
{
    partial class HomePageProductEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtHomeProdTitle = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtNewProdCategory = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtNewProdPrice = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnConfirmNewProd = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(37, 31);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(266, 253);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.DragDrop += new System.Windows.Forms.DragEventHandler(this.pictureBox1_DragDrop);
            this.pictureBox1.DragEnter += new System.Windows.Forms.DragEventHandler(this.pictureBox1_DragEnter);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(328, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 28);
            this.label1.TabIndex = 1;
            this.label1.Text = "Product Title";
            // 
            // txtHomeProdTitle
            // 
            this.txtHomeProdTitle.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtHomeProdTitle.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtHomeProdTitle.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHomeProdTitle.Location = new System.Drawing.Point(333, 64);
            this.txtHomeProdTitle.Multiline = true;
            this.txtHomeProdTitle.Name = "txtHomeProdTitle";
            this.txtHomeProdTitle.Size = new System.Drawing.Size(241, 40);
            this.txtHomeProdTitle.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(41)))), ((int)(((byte)(28)))));
            this.panel1.Location = new System.Drawing.Point(333, 109);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(241, 3);
            this.panel1.TabIndex = 3;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(41)))), ((int)(((byte)(28)))));
            this.panel2.Location = new System.Drawing.Point(333, 195);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(241, 3);
            this.panel2.TabIndex = 6;
            // 
            // txtNewProdCategory
            // 
            this.txtNewProdCategory.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtNewProdCategory.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNewProdCategory.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNewProdCategory.Location = new System.Drawing.Point(333, 150);
            this.txtNewProdCategory.Multiline = true;
            this.txtNewProdCategory.Name = "txtNewProdCategory";
            this.txtNewProdCategory.Size = new System.Drawing.Size(241, 40);
            this.txtNewProdCategory.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(328, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(166, 28);
            this.label2.TabIndex = 4;
            this.label2.Text = "Product Category";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(41)))), ((int)(((byte)(28)))));
            this.panel3.Location = new System.Drawing.Point(333, 281);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(241, 3);
            this.panel3.TabIndex = 9;
            // 
            // txtNewProdPrice
            // 
            this.txtNewProdPrice.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtNewProdPrice.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNewProdPrice.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNewProdPrice.Location = new System.Drawing.Point(333, 236);
            this.txtNewProdPrice.Multiline = true;
            this.txtNewProdPrice.Name = "txtNewProdPrice";
            this.txtNewProdPrice.Size = new System.Drawing.Size(241, 40);
            this.txtNewProdPrice.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(328, 203);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(128, 28);
            this.label3.TabIndex = 7;
            this.label3.Text = "Product Price";
            // 
            // btnConfirmNewProd
            // 
            this.btnConfirmNewProd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(41)))), ((int)(((byte)(28)))));
            this.btnConfirmNewProd.FlatAppearance.BorderSize = 0;
            this.btnConfirmNewProd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConfirmNewProd.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirmNewProd.ForeColor = System.Drawing.Color.White;
            this.btnConfirmNewProd.Location = new System.Drawing.Point(210, 328);
            this.btnConfirmNewProd.Name = "btnConfirmNewProd";
            this.btnConfirmNewProd.Size = new System.Drawing.Size(241, 40);
            this.btnConfirmNewProd.TabIndex = 10;
            this.btnConfirmNewProd.Text = "Edit";
            this.btnConfirmNewProd.UseVisualStyleBackColor = false;
            this.btnConfirmNewProd.Click += new System.EventHandler(this.btnConfirmNewProd_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(70, 287);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(205, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "*please select your image and drop it here";
            // 
            // HomePageProductEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(617, 416);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnConfirmNewProd);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.txtNewProdPrice);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtNewProdCategory);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtHomeProdTitle);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "HomePageProductEdit";
            this.Text = "Edit home page product";
            this.Load += new System.EventHandler(this.HomePageProductEdit_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtHomeProdTitle;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtNewProdCategory;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtNewProdPrice;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnConfirmNewProd;
        private System.Windows.Forms.Label label4;
    }
}