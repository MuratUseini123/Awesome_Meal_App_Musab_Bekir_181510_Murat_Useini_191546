﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Awesome_Meal_App_191546_181510
{
    public partial class FinalPay : Form
    {
        public List<ProductClass> prdcts = new List<ProductClass>();
        public float finalTotal=0;
        public FinalPay()
        {
            InitializeComponent();
        }

        public void addProductToTable(ProductClass newItem)
        {
            this.prdcts.Add(newItem);
            this.finalTotal += newItem.ProductPrice;
        }


        private void FinalPay_Load(object sender, EventArgs e)
        {
            lblFINALTOTAL.Text = "$"+finalTotal.ToString();
            dataGridView1.DataSource = prdcts;
        }
    }
}
